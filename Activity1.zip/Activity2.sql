-- TASK 1--
SELECT COUNT(*) AS TotalMalaysiaAirport
FROM airport
WHERE country = 'Malaysia';

-- TASK 2--
SELECT COUNT(*) AS TotalAirAsiaConfirmedDepartures
FROM booking b
JOIN flight f ON b.flightno = f.flightno
JOIN airplane a ON f.airplanecode = a.airplanecode
WHERE a.airlinename = 'AirAsia'
  AND b.departuredate BETWEEN '2016-06-05' AND '2016-08-15'
  AND b.bookingstatus = 'Confirmed';

-- TASK 3--
SELECT 
    MAX(fd.ticketprice) AS MaxTicketPrice,
    MIN(fd.ticketprice) AS MinTicketPrice
FROM booking b
JOIN flight f ON b.flightno = f.flightno
JOIN airplane a ON f.airplanecode = a.airplanecode
JOIN flightdetails fd 
    ON b.flightno = fd.flightno 
   AND b.departuredate = fd.departuredate
WHERE a.airlinename = 'Malaysia Airlines'
  AND b.bookingdate BETWEEN '2016-04-01' AND '2016-09-15';

-- TASK 4--
SELECT 
    ap.airportcode,
    ap.airportname,
    COUNT(f.flightno) AS NumberOfFlights,
    AVG(fd.duration) AS AverageFlightDuration
FROM airport ap
LEFT JOIN flight f ON ap.airportcode = f.airportcode
LEFT JOIN flightdetails fd ON f.flightno = fd.flightno
GROUP BY ap.airportcode, ap.airportname
ORDER BY ap.airportname ASC;

-- TASK 5--
SELECT 
    p.prfid,
    p.prfname,
    p.prfstate,
    f.arrivalto AS FrequentDestination,
    COUNT(b.bookingid) AS TotalBookings
FROM profile p
JOIN booking b ON p.prfid = b.prfid
JOIN flight f ON b.flightno = f.flightno
GROUP BY p.prfid, p.prfname, p.prfstate, f.arrivalto
HAVING COUNT(b.bookingid) > 1;

-- TASK 6--
SELECT 
    p.prfid,
    p.prfname,
    SUM(fd.ticketprice) AS TotalTicketPrice
FROM profile p
JOIN booking b ON p.prfid = b.prfid
JOIN flightdetails fd 
    ON b.flightno = fd.flightno 
   AND b.departuredate = fd.departuredate
GROUP BY p.prfid, p.prfname
HAVING SUM(fd.ticketprice) > (
    SELECT AVG(fd2.ticketprice)
    FROM flightdetails fd2
    JOIN flight f2 ON fd2.flightno = f2.flightno
    JOIN airplane a2 ON f2.airplanecode = a2.airplanecode
    WHERE a2.airlinename = 'AirAsia'
);